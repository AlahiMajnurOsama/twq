import { HttpError } from 'wasp/server';

export const getUser = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const user = await context.entities.User.findUnique({
    where: { id },
    select: {
      id: true,
      username: true,
      email: true,
      password: true,
      role: true,
      bio: true,
      skills: true,
      contact: true,
      profileImage: true,
      coverImage: true,
      Course: true,
      Project: true
    }
  });

  if (!user) { throw new HttpError(404, 'No user with id ' + id); }

  return user;
}

export const getCourse = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const course = await context.entities.Course.findUnique({
    where: { id },
    include: { instructor: true, Assignment: true }
  });

  if (!course) { throw new HttpError(404, 'No course with id ' + id); }

  return course;
}

export const getAssignment = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const assignment = await context.entities.Assignment.findUnique({
    where: { id },
    include: { course: true }
  });

  if (!assignment) { throw new HttpError(404, 'No assignment with id ' + id); }

  return assignment;
}

export const getProject = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const project = await context.entities.Project.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      description: true,
      status: true,
      userId: true,
      user: true
    }
  });

  if (!project) { throw new HttpError(404, 'No project with id ' + id); }

  return project;
}