import { HttpError } from 'wasp/server'

export const createUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.User.create({
    data: {
      username: args.username,
      email: args.email,
      password: args.password,
      role: args.role,
      bio: args.bio,
      skills: args.skills,
      contact: args.contact,
      profileImage: args.profileImage,
      coverImage: args.coverImage
    }
  });
}

export const createCourse = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Course.create({
    data: {
      title: args.title,
      instructorId: args.instructorId,
      path: args.path,
      status: args.status
    }
  });
}

export const createAssignment = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const course = await context.entities.Course.findUnique({
    where: { id: args.courseId }
  });
  if (!course) { throw new HttpError(404, `Course with id ${args.courseId} not found`) };

  return context.entities.Assignment.create({
    data: {
      title: args.title,
      description: args.description,
      dueDate: args.dueDate,
      status: args.status,
      course: { connect: { id: args.courseId } }
    }
  });
}

export const createProject = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Project.create({
    data: {
      title: args.title,
      description: args.description,
      status: args.status,
      user: {
        connect: { id: args.userId }
      }
    }
  });
}