import React from 'react';
import { useQuery, getUser, getCourse, getAssignment, getProject } from 'wasp/client/operations';

const SuperAdminPage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: course, isLoading: courseLoading, error: courseError } = useQuery(getCourse);
  const { data: assignment, isLoading: assignmentLoading, error: assignmentError } = useQuery(getAssignment);
  const { data: project, isLoading: projectLoading, error: projectError } = useQuery(getProject);

  if (userLoading || courseLoading || assignmentLoading || projectLoading) return 'Loading...';
  if (userError || courseError || assignmentError || projectError) return 'Error: ' + (userError || courseError || assignmentError || projectError);

  return (
    <div className='p-4'>
      <div>
        <h1>User Details:</h1>
        <p>Username: {user.username}</p>
        <p>Email: {user.email}</p>
        <h1>Course Details:</h1>
        <p>Course Title: {course.title}</p>
        <p>Instructor: {course.instructor.username}</p>
        <h1>Assignment Details:</h1>
        <p>Title: {assignment.title}</p>
        <p>Description: {assignment.description}</p>
        <h1>Project Details:</h1>
        <p>Title: {project.title}</p>
        <p>Description: {project.description}</p>
      </div>
    </div>
  );
}

export default SuperAdminPage;