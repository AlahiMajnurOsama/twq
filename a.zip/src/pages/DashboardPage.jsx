import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, getUser, getCourse, getAssignment, getProject } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: course, isLoading: courseLoading, error: courseError } = useQuery(getCourse);
  const { data: assignment, isLoading: assignmentLoading, error: assignmentError } = useQuery(getAssignment);
  const { data: project, isLoading: projectLoading, error: projectError } = useQuery(getProject);

  if (userLoading || courseLoading || assignmentLoading || projectLoading) return 'Loading...';
  if (userError || courseError || assignmentError || projectError) return 'Error: ' + (userError || courseError || assignmentError || projectError);

  return (
    <div className='p-4'>
      <div>{user?.username}</div>
      <div>{course?.title}</div>
      <div>{assignment?.title}</div>
      <div>{project?.title}</div>
    </div>
  );
}

export default DashboardPage;