import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, getProject } from 'wasp/client/operations';

const LandingPage = () => {
  const { data: projects, isLoading, error } = useQuery(getProject);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {projects.map((project) => (
        <div key={project.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{project.title}</div>
          <div>{project.description}</div>
          <Link to={`/project/${project.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>Details</Link>
        </div>
      ))}
    </div>
  );
}

export default LandingPage;