import React from 'react';
import { useQuery, getUser, getCourse, getAssignment, getProject } from 'wasp/client/operations';

const AdminPage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: course, isLoading: courseLoading, error: courseError } = useQuery(getCourse);
  const { data: assignment, isLoading: assignmentLoading, error: assignmentError } = useQuery(getAssignment);
  const { data: project, isLoading: projectLoading, error: projectError } = useQuery(getProject);

  if (userLoading || courseLoading || assignmentLoading || projectLoading) return 'Loading...';
  if (userError || courseError || assignmentError || projectError) return 'Error: ' + (userError || courseError || assignmentError || projectError);

  return (
    <div className='p-4'>
      <div>
        <h1>User Information</h1>
        <p>Username: {user.username}</p>
        <p>Email: {user.email}</p>
        <p>Role: {user.role}</p>
      </div>
      <div>
        <h1>Course Information</h1>
        {course.map((course) => (
          <div key={course.id}>
            <p>Title: {course.title}</p>
            <p>Instructor: {course.instructor.username}</p>
            <p>Status: {course.status}</p>
          </div>
        ))}
      </div>
      <div>
        <h1>Assignment Information</h1>
        {assignment.map((assignment) => (
          <div key={assignment.id}>
            <p>Title: {assignment.title}</p>
            <p>Description: {assignment.description}</p>
            <p>Due Date: {assignment.dueDate}</p>
            <p>Status: {assignment.status}</p>
          </div>
        ))}
      </div>
      <div>
        <h1>Project Information</h1>
        {project.map((project) => (
          <div key={project.id}>
            <p>Title: {project.title}</p>
            <p>Description: {project.description}</p>
            <p>Status: {project.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AdminPage;